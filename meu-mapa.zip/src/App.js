import React from "react";
import MapaComponent from "./MapaComponent";
import './index.css';

function App() {
  return (
    <div>
      <h2 style={{ textAlign: "center" }}>Meu Mapa com React e Leaflet</h2>
      <MapaComponent />
    </div>
  );
}

export default App;
